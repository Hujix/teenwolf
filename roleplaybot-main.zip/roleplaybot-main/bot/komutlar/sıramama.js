const Discord = require("discord.js");
const db = require("quick.db");
exports.run = async (client, message, args) => {
  let sıralama = message.guild.members
    .filter(a => a.user.bot == false)
    .array()
    .sort((a, b) => {
      return (
        db.fetch(`sa_${message.guild.id}_${b.user.id}`) -
        db.fetch(`sa_${message.guild.id}_${a.user.id}`)
      );
    });
  let sırala = "";
  for (let i = 0; i < 10; i++) {
    if (
        null &&
      db.fetch(`sa_${message.guild.id}_${sıralama[i].id}`) != 0
    ) {
      sırala +=
        `[${i + 1}]: ` +
        sıralama[i] +
        `` +
        " | " +
        db.fetch(`sa_${message.guild.id}_${sıralama[i].id}`) +
        "kelime\n";
    }
  }
  const embed = new Discord.RichEmbed()
    .setDescription(`${sırala == "" ? "ne diyon amk kimse rp yapmamamış" : sırala}`)
    .setColor("ddd244");

  message.channel.send(embed);
};

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: [],
  permLevel: 0
};

exports.help = {
  name: "sıralama",
  description: "Roleplay içerisindeki sıralamanıza",
  usage: "toplamgümüş"
};
