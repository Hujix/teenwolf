const Discord = require('discord.js');
const ms = require('parse-ms')
const db = require('quick.db')
const ayarlar = require("../ayarlar.json")

exports.run = async(client, message, args) => { 
  let para = await db.fetch(`puans_${message.author.id}`)
  let altın = await db.fetch(`altın_${message.author.id}`)
  let banka = await db.fetch(`banka_${message.author.id}`)
  let kredi = await db.fetch(`kredi_${message.author.id}`)  
  let bankadeğer = await db.fetch(`bankadeger_${message.author.id}`)
  let şifre = await db.fetch(`sifre_${message.author.id}`)
  let süre = await db.fetch(`kartsure_${message.author.id}`)
  let timeObj = ms(Date.now() - süre);  
  var filtre = m => m.author.id === message.author.id

  if(!banka) {
     var embed = new Discord.RichEmbed()
  .setDescription('Banka Hesabın Bulunmamaktadır!')
            .setThumbnail(message.author.avatarURL)
  .setColor('RED')
  message.channel.sendEmbed(embed)
    return
  }
  
  
   var embed = new Discord.RichEmbed()
    .setTitle('İşte Bilgilerin!')
.addField(`**Banka**`, ` \`\`${bankadeğer}\`\`  `)// 
       .setThumbnail(message.author.avatarURL)
  .setTimestamp();
message.channel.send(embed)
  
 
 /////////////////////////////////////////////////////////////////////////////////////////

 

 
};
exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ["s"],
  permLevel: 0
};

exports.help = {
  name: 'banka',
  description: 'Gelişmiş Sayfalı Yardım.',
  usage: 'şirket-ayarlar'
};