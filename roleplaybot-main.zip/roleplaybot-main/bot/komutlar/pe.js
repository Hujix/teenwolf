const Discord = require('discord.js');
const db = require('quick.db');

exports.run = (client,message,args) => {
    if(!message.member.roles.has("779066992510107691")) return message.channel.send(`:no_entry: Bu komudu kullanabilmek için yeterli yetkiye sahip değilsin.`)  

const hüso = message.mentions.users.first() || args.slice(0).join(' ')

if(!hüso) return message.channel.send(
new Discord.RichEmbed()
.setColor('BLUE')
.setDescription('Kimden ne kadar kesilecek')
)
const alp = args.slice(1).join(' ')
if(!alp) return message.channel.send(
new Discord.RichEmbed()
.setColor('BLUE')
.setDescription('Kaç para')
)
  if (isNaN(args[1])) return;
 	const alps = new Discord.RichEmbed()
.setColor('BLUE')
.setDescription(`Başarılı!`)
message.channel.send(alps)
db.subtract(`para_${hüso.id}`, args[1])
}

exports.conf = {
enabled: true,
guildOnly: false,
permLevel: 0,
aliases: []
}


exports.help = {
name: 'pe'	
}