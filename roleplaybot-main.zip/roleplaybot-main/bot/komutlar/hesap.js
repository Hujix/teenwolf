const Discord = require('discord.js');
const db = require('quick.db')
exports.run = (client, message, args) => { 
  let banka = db.fetch(`banka_${message.author.id}`)
 let para = db.fetch(`puan_${message.author.id}`)
 let altın = db.fetch(`altın_${message.author.id}`)
let şifre = db.fetch(`sifre_${message.author.id}`)
 let kredi = db.fetch(`kredi_${message.author.id}`)   
let isim = args[0] 
let sifre = args[1] 


if(banka) {

  var embed = new Discord.RichEmbed()
  .setDescription(message.member.user.username + ' Zaten bankan bulunuyo')
  .setColor('RED')
  .setThumbnail(message.author.avatarURL)
.setTimestamp()
  message.channel.sendEmbed(embed)
  return

}

if(!isim) {
  var embed = new Discord.RichEmbed()
  .setDescription('Bir isim belirt!')
    .setThumbnail(message.author.avatarURL)
  .setColor('RED')
.setTimestamp()
  message.channel.sendEmbed(embed)
  return
}
  
if(!sifre) {
  var embed = new Discord.RichEmbed()
  .setDescription('Bir şifre belirt!')
    .setThumbnail(message.author.avatarURL)
  .setColor('RED')
.setTimestamp()
  message.channel.sendEmbed(embed)
  return
}

  
 	const alps = new Discord.RichEmbed()
.setColor('#FB529C')
.setDescription('İşlem Başarılı hesap Açtın Ve Sistem Otomatik Olarak Giriş Yaptı')
    .setThumbnail(message.author.avatarURL)
.setTimestamp()
message.channel.send(alps)  
  
db.set(`banka_${message.author.id}`, isim)
   db.set(`bankadeger_${message.author.id}`, 0)


    
  };
exports.conf = {
  enabled: true, 
  guildOnly: false, 
  aliases: ['sirket'], 
  permLevel: 0 
};

exports.help = {
  name: 'hesap-aç', 
  description: 'şirket', 
  usage: 'şirket'
};

