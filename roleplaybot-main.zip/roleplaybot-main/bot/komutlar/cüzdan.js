const Discord = require("discord.js");
const db = require("quick.db");

module.exports.run = async (client, message, args) => {   
    
    let para = db.get(`${message.author.id}_para_${message.guild.id}`)

    let kisi = message.guild.member(message.mentions.users.first() || message.guild.members.get(args[0]));



    if (!kisi) {
    if(!para) {
        return message.channel.send(`💰 ${message.author}, Cüzdanınızda **0** $ Dolarınız bulunmaktadır.`)
    } else {
        if(para >= "5000") {
        return message.channel.send(`💰 ${message.author}, Cüzdanınızda **${para}**$ Dolarınız bulunmaktadır.`)
        } else {
            return message.channel.send(`💰 ${message.author}, Banka hesabınızda **${para}** Altınınız bulunmaktadır.`) 
        }
    } 
        
    } else {
        let para2 = db.get(`${kisi.user.id}_para_${message.guild.id}`)
        if(!para2) {
            return message.channel.send(`💰 ${kisi}, adlı kullanıcının Banka hesabında **0** Altını bulunmaktadır.`)
        } else {
            if(para2 >= "5000") {
                message.channel.send(`💰 ${kisi}, adlı kullanıcının Banka hesabında **${para2}** Altını bulunmaktadır.`)  
            } else {
                return message.channel.send(`💰 ${kisi}, adlı kullanıcının Banka hesabında **${para2}** Altını bulunmaktadır.`) 
            }
    }

    }
        



};
exports.conf = {
  enabled: true,
  guildOnly: true,
  aliases: ["b"],
  permLevel: 0
};

exports.help = {
  name: "cüzdan",
  description: "Bakiyenizi görüntülersiniz.",
  usage: "!bakiye"
};
