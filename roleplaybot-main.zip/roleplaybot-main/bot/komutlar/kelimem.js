const Discord = require("discord.js");
const db = require('quick.db')
exports.run = async (client, message, args) => {
  

    let user = message.mentions.users.first() || message.author

    let sorted = message.guild.members.filter(a => a.user.bot == false).array().sort((a , b) => {return db.fetch(`twk_${message.guild.id}_${b.user.id}`) - db.fetch(`twk_${message.guild.id}_${a.user.id}`) })
let ne = await db.fetch(`twk_${message.guild.id}_${user.id}`)
  if (ne === null) ne = 0;

    let sira = "";
    for (var i = 0; i < sorted.length; i++) {
        if (sorted[i].id === user.id) {
            sira += `${i + 1}`
        }
    }  




    const embed = new Discord.RichEmbed()
 .setThumbnail(user.avatarURL)
      .setDescription(`**RpList Sıralaması** \n\n  \`\`${sira}\`\` \n\n **Toplam Rp Kelimesi** \n\n \`\`${ne}\`\`  `)
    message.channel.send(embed)
}




exports.conf = {
    enabled: true,
    guildOnly: false,
    aliases: ["KELİMEM"],
    permLevel: 0
};

exports.help = {
    name: 'kelimem',
    description: 'sıralama bak lan',
    usage: 'sıralamam'
};

 