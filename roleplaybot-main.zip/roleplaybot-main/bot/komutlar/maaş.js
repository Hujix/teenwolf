const Discord = require('discord.js');
const db = require('quick.db');

exports.run = (client, message, args) => {
    if(!message.member.roles.has("rolid")) return message.channel.send(`yetkin yko!`)  

  
 let rol = args[0]
if(!rol) return message.channel.send("rol etiketle")
   let sa = args[1]
if(!sa) return message.channel.send("kaç tl ekliyim")

let rol2 = message.mentions.roles.first() || args.slice(0).join(' ')
let roldekiler = rol2.members.forEach(f => {
db.add(`puan_${f.id}` ,args[1])
  
  const as = new Discord.RichEmbed()
.setColor('BLUE')
.setDescription(`Roldekilere parası verildi `)
message.channel.send(as)
})
}


exports.conf = {
enabled: true,
guildOnly: false,
permLevel: 0,
aliases: ["MAAŞ"]
}


exports.help = {
name: 'maaş'	
}