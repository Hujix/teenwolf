<h1>Teen Wolf Altyapı</h1>

<a href="https://discord.gg/Sf9XES6">
  Sunucuya Gelmek için Tıkla! </a>
  
  <h1></h1>
  

<h1>Yapılan hakaretler hiç bir zaman cezasız kalmaz </h1>
  
  
  
_Bilmeniz gereken bilgiler_

**Altyapı sahiblerinden izin aldıktan sonra** istediğiniz gibi paylaşabilirsiniz.

**Herkes Teen Wolf RolePlayi** sunucusu açmalı bence onun için kullanıp thanks atar mısın?

**Sorun yaşarsanız** sahiplerine ulaşmanız yeterlidir.

**Altyapılarını** yaptığım **kişiliksiz** insanlar kendini **çok iyi** biliyor.

SONRA AYAĞIMIZA GELMEYİN :D


## Ayağımıza geldiğinizde Altyapınızı herkes bilmiş olacak...

_Altyapı Sahipleri İyi Günler Diliyor!_

_Altyapıyı Githubda paylaşabilirsiniz__
